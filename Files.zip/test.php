<?php
class Mahasiswa
{
    public $nim;
    private $nama;
	protected $nilai;

    public function __construct($nim, $nama, $nilai)
    {
        $this->nim = $nim;
        $this->nama = $nama;
        $this->nilai = $nilai;
    }

    protected function StatusNilai()
    {
        if ($this->nilai >= 70) {
            $status = "Lulus";
        } else {
            $status = "Gagal";
        }
        return $status;
    }

    public function BacaNama()
    {
        return $this->nama;
    }

    public function BacaNilai()
    {
        return $this->nilai;
    }
}

/**

* Class Turunan Mahasiswa dengan nama class Nilai

*/

class Nilai extends Mahasiswa
{
    public $status;

    public function BacaStatus()
    {
        $this->status = $this->StatusNilai();
        return $this->status;
    }
}

$turunan = new Nilai(1430511105, 'Gun Gun Priatna', 95);
echo "NIM : ".$turunan->nim."<br />";
echo "Nama : ".$turunan->BacaNama()."<br />";
echo "Nilai : ".$turunan->BacaNilai()."<br />";
echo "Status : ".$turunan->BacaStatus()."<br />";
?>