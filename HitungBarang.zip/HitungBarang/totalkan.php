<?php
$nmbrng= $_POST['namabarang'];
$hrgbrng= $_POST['hargabarang'];
$jmlbrng= $_POST['jumlahbarang'];
$hasilnya;
 function hitung ($hrgbrng,$jmlbrng) {
 	$hargaaa=$hrgbrng;
 	$jumlahhh=$jmlbrng;
 	$hasilnya=$hargaaa*$jumlahhh;
 	return $hasilnya;
 }
 $hasilnya= hitung($hrgbrng,$jmlbrng);
 echo "Nama Barang= ".$nmbrng."<br>";
 echo "Harga Barang= ".$hrgbrng."<br>";
 echo "Jumlah Barang= ".$jmlbrng."<br>";
 echo " Total belanja semuanya adalah = $hasilnya";
 switch ($hrgbrng) {
	case ($hasilnya<200000):
	echo "Mohon maaf belanja anda masih kurang kurang";
	break;
	case ($hasilnya>=400000 && $hasilnya<1000000):
	$diskon=0.2;
	$x=$hasilnya-($diskon*$hasilnya);
	echo "karena total belanja anda >= Rp.", $hasilnya, " Maka kami beri diskon 20%.". $diskon."<br>";
	break;
	case ($hasilnya>=200000 || $hasilnya<400000):
	$diskon=0.1;
	$x=$hasilnya-($diskon*$hasilnya);
	echo "karena total belanja anda >= Rp.", $hasilnya, " Maka kami beri diskon 10%.". $diskon."<br>";
	break;
	default:
	echo "Mohon maaf belanja anda melebihi batas ketentuan";
	break;
	}
?>